import os

class Book:
    def __init__(self, title, author, status="available"):
        self._title = title
        self._author = author
        self._status = status

    def get_title(self):
        return self._title

    def get_status(self):
        return self._status

    def set_status(self, status):
        self._status = status

    def __str__(self):
        return f"{self._title} | {self._author} | {self._status}"


class Person:
    def __init__(self, name):
        self._name = name

    def get_name(self):
        return self._name

    def get_role(self):
        raise NotImplementedError


class Librarian(Person):
    def get_role(self):
        return "librarian"


class Reader(Person):
    def __init__(self, name):
        super().__init__(name)
        self._borrowed_books = []

    def get_role(self):
        return "reader"

    def borrow_book(self, title):
        self._borrowed_books.append(title)

    def return_book(self, title):
        self._borrowed_books.remove(title)

    def get_books(self):
        return self._borrowed_books

class LibrarySystem:
    def __init__(self):
        self.books = []
        self.users = []
        self.load_data()

    def load_data(self):
        if os.path.exists("books.txt"):
            with open("books.txt", "r", encoding="utf-8") as f:
                for line in f:
                    title, author, status = line.strip().split(";")
                    self.books.append(Book(title, author, status))

        if os.path.exists("users.txt"):
            with open("users.txt", "r", encoding="utf-8") as f:
                for line in f:
                    parts = line.strip().split(";")
                    user = Reader(parts[0])
                    if len(parts) > 1 and parts[1]:
                        user._borrowed_books = parts[1].split(",")
                    self.users.append(user)

    def save_data(self):
        with open("books.txt", "w", encoding="utf-8") as f:
            for book in self.books:
                f.write(f"{book._title};{book._author};{book._status}\n")

        with open("users.txt", "w", encoding="utf-8") as f:
            for user in self.users:
                books = ",".join(user.get_books())
                f.write(f"{user.get_name()};{books}\n")

    def add_book(self, title, author):
        self.books.append(Book(title, author))

    def remove_book(self, title):
        self.books = [b for b in self.books if b.get_title() != title]

    def register_user(self, name):
        self.users.append(Reader(name))

    def show_users(self):
        for user in self.users:
            print(user.get_name())

    def show_books(self):
        for book in self.books:
            print(book)

    def show_available_books(self):
        for book in self.books:
            if book.get_status() == "available":
                print(book)

    def borrow_book(self, user, title):
        for book in self.books:
            if book.get_title() == title:
                if book.get_status() == "available":
                    book.set_status("borrowed")
                    user.borrow_book(title)
                    print("книга выдана")
                else:
                    print("книга уже выдана")
                return
        print("книга не найдена")

    def return_book(self, user, title):
        for book in self.books:
            if book.get_title() == title:
                book.set_status("available")
                user.return_book(title)
                print("книга возвращена")
                return

library = LibrarySystem()

role = input("выберите роль (1 — библиотекарь, 2 — пользователь): ")

if role == "1":
    librarian = Librarian("Admin")
    while True:
        print("\n1. добавить книгу\n2. удалить книгу\n3. зарегистрировать пользователя\n4. показать пользователей\n5. показать книги\n0.выход")
        choice = input("Выбор: ")

        if choice == "1":
            library.add_book(input("название: "), input("автор: "))
        elif choice == "2":
            library.remove_book(input("название: "))
        elif choice == "3":
            library.register_user(input("имя: "))
        elif choice == "4":
            library.show_users()
        elif choice == "5":
            library.show_books()
        elif choice == "0":
            break

elif role == "2":
    name = input("введите имя: ")
    user = next((u for u in library.users if u.get_name() == name), None)

    if not user:
        print("пользователь не найден")
    else:
        while True:
            print("\n1. доступные книги\n2. взять книгу\n3. вернуть книгу\n4. мои книги\n0. выход")
            choice = input("выбор: ")

            if choice == "1":
                library.show_available_books()
            elif choice == "2":
                library.borrow_book(user, input("название: "))
            elif choice == "3":
                library.return_book(user, input("название: "))
            elif choice == "4":
                print(user.get_books())
            elif choice == "0":
                break

library.save_data()